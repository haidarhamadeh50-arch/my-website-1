// script.js - handles lessons interactive content and quiz logic
document.addEventListener('DOMContentLoaded', function(){
  // Lesson content
  const lessons = {
    input: {
      title: 'How to input data',
      body: '<p>Input means reading values from the user. Examples show pseudocode and JS snippets.<\/p>' +
            '<pre><code>// JavaScript example:\nconst name = prompt(\'Enter name:\');\nconsole.log(\'Hello, \' + name);</code></pre>'
    },
    operators: {
      title: 'Basic Numeric Operators',
      body: '<p>Operators: +, -, *, /, % (modulus). Example below shows sum and average.<\/p>' +
            '<pre><code>// JS example:\nconst a=5, b=3;\nconst sum = a + b;\nconst avg = sum / 2;\nconsole.log(sum, avg);</code></pre>'
    },
    conditions: {
      title: 'Conditions (if / else)',
      body: '<p>Conditions let the program choose based on boolean tests.<\/p>' +
            '<pre><code>// JS example:\nconst n = 4;\nif(n % 2 === 0) console.log(\'Even\'); else console.log(\'Odd\');</code></pre>'
    },
    loops: {
      title: 'Loops (for / while)',
      body: '<p>Loops repeat actions. For-loops and while-loops are common.<\/p>' +
            '<pre><code>// JS example:\nfor(let i=1;i<=5;i++){ console.log(i); }</code></pre>'
    }
  };

  // Bind lesson buttons
  document.querySelectorAll('.lesson-btn').forEach(btn=>{
    btn.addEventListener('click', ()=> {
      const topic = btn.dataset.topic;
      const container = document.getElementById('lesson-body');
      container.innerHTML = '<h4>' + lessons[topic].title + '</h4>' + lessons[topic].body;
    });
  });

  // Quiz logic
  const quizzes = {
    input: [
      {q:'Which function in JS asks user for a value?', options:['alert','prompt','confirm','console.log'], a:1},
      {q:'Input value from prompt is returned as which type?', options:['number','string','boolean','object'], a:1},
      {q:'Which is a good example of reading name?', options:['const n = prompt(\'Name?\')','const n = input()','read(n)','scan(n)'], a:0}
    ],
    operators: [
      {q:'What is 5 % 2?', options:['2','1','0','3'], a:1},
      {q:'Which operator multiplies?', options:['+','-','*','/'], a:2},
      {q:'Average of 4 and 6 is?', options:['5','10','2','4'], a:0}
    ],
    conditions: [
      {q:'Which compares equality in JS (strict)?', options:['==','===','~=','equals'], a:1},
      {q:'if (x > 5) else is used when?', options:['x>5','x<=5','x==5','always'], a:1},
      {q:'Boolean values are?', options:['true/false','1/0','yes/no','on/off'], a:0}
    ],
    loops: [
      {q:'Which loop runs fixed number of times?', options:['while','do-while','for','until'], a:2},
      {q:'for (let i=0;i<3;i++) runs how many times?', options:['2','3','4','1'], a:1},
      {q:'Which loop checks condition after running once?', options:['for','while','do-while','none'], a:2}
    ]
  };

  function renderQuiz(topic){
    const area = document.getElementById('quiz-area');
    area.innerHTML = '';
    const qs = quizzes[topic];
    if(!qs) return;
    const form = document.createElement('form');
    qs.forEach((item, idx)=>{
      const div = document.createElement('div');
      div.className = 'quiz-question';
      const p = document.createElement('p');
      p.textContent = (idx+1) + '. ' + item.q;
      div.appendChild(p);
      const opts = document.createElement('div');
      opts.className = 'q-options';
      item.options.forEach((opt, oi)=>{
        const label = document.createElement('label');
        const input = document.createElement('input');
        input.type = 'radio';
        input.name = 'q'+idx;
        input.value = oi;
        label.appendChild(input);
        label.appendChild(document.createTextNode(' ' + opt));
        opts.appendChild(label);
      });
      div.appendChild(opts);
      form.appendChild(div);
    });

    const btn = document.createElement('button');
    btn.type='button';
    btn.className='primary';
    btn.textContent='Submit';
    btn.addEventListener('click', ()=>{
      // score
      let correct=0;
      qs.forEach((item, idx)=>{
        const sel = form.querySelector('input[name=q'+idx+']:checked');
        if(sel && parseInt(sel.value) === item.a) correct++;
      });
      const result = document.createElement('div');
      result.className='result';
      result.textContent = 'Score: ' + correct + ' / ' + qs.length;
      // remove previous result if any
      const prev = area.querySelector('.result');
      if(prev) prev.remove();
      area.appendChild(result);
      area.appendChild(document.createElement('hr'));
    });

    form.appendChild(btn);
    area.appendChild(form);
  }

  // Start quiz button
  const startBtn = document.getElementById('start-quiz');
  if(startBtn){
    startBtn.addEventListener('click', ()=>{
      const topic = document.getElementById('topic-select').value;
      renderQuiz(topic);
    });
  }

  // If page contains quiz area on load with default select
  if(document.getElementById('quiz-area') && document.getElementById('topic-select')){
    // no-op, wait for user click
  }
});
